
public class Topic2_Assign2 {

	public static void main(String[] args) {
		Email email = new Email("Hi, we have a meeting", "Boss", "Me", "Meeting");
		System.out.println(email.toString());

	}

}
