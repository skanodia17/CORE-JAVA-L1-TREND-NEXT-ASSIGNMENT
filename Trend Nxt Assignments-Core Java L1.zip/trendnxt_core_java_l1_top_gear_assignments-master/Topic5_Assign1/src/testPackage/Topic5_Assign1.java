package testPackage;

public class Topic5_Assign1 {

	public static void main(String[] args) {
		Foundation fd = new Foundation();
		System.out.println(fd.var2);
		System.out.println(fd.var3);
		System.out.println(fd.var4);

	}

}
