
public class Topic5_Assign2 {
	
	// companyName City
	public static void main(String[] args) {
		String companyName = args[0];
		String cityName = args[1];
		String tech = "Technologies";
		String newStr = companyName + " " + tech + " " + cityName;
		System.out.println(newStr);

	}

}
