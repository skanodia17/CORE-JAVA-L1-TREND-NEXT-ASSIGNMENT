
public class A1 {

	A1(){
		
	}
	public void finalize(){
		System.out.println("Finalized Method called.");
	}
}
