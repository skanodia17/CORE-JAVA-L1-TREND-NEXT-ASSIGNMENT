
public abstract class Instrument {
	abstract void play();
}
