
public class Topic1_Assign2 {

	public static void main(String[] args) {
		// a.  -5 + 8 * 6
		double a = -5 + 8 * 6;
		System.out.println(a);
		
		// b.  (55+9) % 9
		double b = (55+9) % 9;
		System.out.println(b);
		
		// c.  20 + -3*5 / 8
		double c = 20+ -3.0*5.0/8.0; // added the #.0 so i can get the correct answer
		System.out.println(c);
		
		
		// d.  5 + 15 / 3 * 2 - 8 % 3
		double d = 5 + 15/3 *2 - 8 % 3;
		System.out.println(d);



	}

}
